# Shepherd
Open source integrated cloud solution
->Aggregate all your digital tools into one single space, backup and secure
-> In early phases of development
-> Developed by Azzurro Technology
